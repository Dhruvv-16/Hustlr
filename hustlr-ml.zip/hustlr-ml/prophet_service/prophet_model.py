import os
import time
import requests
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from prophet import Prophet
from scipy.stats import norm

MODEL_PATH = Path(__file__).parent.parent / "models" / "prophet_chennai.pkl"

def fetch_open_meteo_historical() -> pd.DataFrame:
    """
    Fetch 2018-2024 daily rainfall data for Chennai via Open-Meteo Historical Archive API.
    Lat: 13.0827, Lng: 80.2707
    """
    url = (
        "https://archive-api.open-meteo.com/v1/archive?"
        "latitude=13.0827&longitude=80.2707&"
        "start_date=2018-01-01&end_date=2024-12-31&"
        "daily=precipitation_sum&timezone=Asia/Kolkata"
    )
    
    response = requests.get(url, timeout=10)
    response.raise_for_status()
    data = response.json()
    
    dates = data["daily"]["time"]
    precip = data["daily"]["precipitation_sum"]
    
    df = pd.DataFrame({
        "ds": pd.to_datetime(dates),
        "y": precip
    })
    
    # Fill any NaNs with 0
    df["y"] = df["y"].fillna(0)
    
    return df

def add_regressors(df: pd.DataFrame) -> pd.DataFrame:
    months = df["ds"].dt.month
    
    # User Spec: is_monsoon [6,7,8,9,10,11]
    df["is_monsoon"] = months.isin([6, 7, 8, 9, 10, 11]).astype(int)
    
    # User Spec: is_cyclone_season [10,11,12]
    df["is_cyclone_season"] = months.isin([10, 11, 12]).astype(int)
    
    return df

def train_model():
    """
    Train and save the Prophet model using real historical precipitation data.
    """
    print("[Prophet] Fetching historical IMD data via Open-Meteo fallback...")
    df = fetch_open_meteo_historical()
    df = add_regressors(df)
    
    print("[Prophet] Training model...")
    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=False,
        changepoint_prior_scale=0.1
    )
    
    model.add_regressor("is_monsoon")
    model.add_regressor("is_cyclone_season")
    
    model.fit(df)
    
    # Ensure directory exists
    MODEL_PATH.parent.mkdir(exist_ok=True)
    import joblib
    joblib.dump(model, MODEL_PATH)
    print(f"[Prophet] Model saved to {MODEL_PATH}")

def load_model():
    import joblib
    if not MODEL_PATH.exists():
        train_model()
    return joblib.load(MODEL_PATH)

def generate_forecast(zone_id: str, days: int = 7) -> dict:
    """
    Generate forecast for the next `days`.
    Compute disruption_probability using Normal CDF on yhat boundaries.
    """
    model = load_model()
    
    future = model.make_future_dataframe(periods=days, freq='D')
    future = add_regressors(future)
    
    forecast = model.predict(future)
    
    # Slice the last `days` segment representing the future
    future_forecast = forecast.tail(days)
    
    results = []
    for _, row in future_forecast.iterrows():
        yhat = row["yhat"]
        yhat_upper = row["yhat_upper"]
        yhat_lower = row["yhat_lower"]
        
        # Sigma derived from 80% CI interval (z=1.28)
        sigma = (yhat_upper - yhat_lower) / (2 * 1.28)
        
        # CDF calculation against 64.5mm threshold for extreme disruption
        if sigma > 0:
            prob = 1.0 - norm.cdf(64.5, loc=yhat, scale=sigma)
        else:
            prob = 1.0 if yhat > 64.5 else 0.0
            
        prob = float(np.clip(prob, 0.0, 1.0))
        predicted_rain = float(np.clip(yhat, 0.0, None))
        
        trigger = "none"
        if prob > 0.05:
            trigger = "heavy_rain"
            if prob > 0.3:
                trigger = "extreme_rain"
                
        results.append({
            "date": row["ds"].strftime("%Y-%m-%d"),
            "predicted_rainfall_mm": round(predicted_rain, 2),
            "disruption_probability": round(prob, 4),
            "trigger_type": trigger,
            "expected_payout_standard_shield": 40.0 if trigger != "none" else 0.0
        })
        
    return {
        "zone_id": zone_id,
        "forecasts": results
    }
